using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;
using System.IO;
using System.Text;
using UnityEditor;

public class Earthquakes : MonoBehaviour {
	
	private GameObject tunnel;
	public GameObject earthMap;
	public GameObject SolarSystem;
	private GameObject SPECTATORPOV;
	private GameObject PointLight2;
	private GameObject DirectionLight;
	private LoadJSON PropertiesFromJson;
	private ulong oldTime;
	private ulong actualTime;
	private AudioSource audio2;
	private AudioSource audio3;
	public bool trig = false;
	public float duration = 11.0F; 
    public Color color0 = Color.white;
    public Color color1 = Color.blue;
	private int numMaxTerremoti = 1000; // num.Max di GameObject visualizzati in json all_hour
    public GameObject[] ArrayTerremotiGameObject; 
	public TextMesh[] text3dMesh;
	public TextMesh TextSelector;
	public GameObject selector; // seleziono il poligono
	private int capacity = 1; // inizializzo la capacità degli array a 1 
	public int cnt = -1;
	public bool sph = true;
	public bool tun = true;
	public Vector3 outCart;

	
	void Awake () {
	    
		PropertiesFromJson = GetComponent<LoadJSON>(); // prelevo attraverso GetComponent le variabili che si trovano in LoadJson
		AudioSource[] sources;
		sources = GetComponents<AudioSource>();
		audio2 = sources[2];		 
	}
	
	void Start () {
		
		actualTime = 0;
		oldTime = 0;
		DirectionLight = GameObject.Find("Directional light");
		PointLight2 = GameObject.Find("Point light 2");
		tunnel = GameObject.Find("TUNNEL8");
		earthMap = GameObject.Find("earthMap");
		SolarSystem = GameObject.Find("SolarSystem");
		SPECTATORPOV = GameObject.Find("SPECTATOR POV");
		// creo un Array di Gameobject con una capacità fissa numMaxTerremoti 
		ArrayTerremotiGameObject = new GameObject[numMaxTerremoti]; 
	}
	
	void Update () {
		
		if (PropertiesFromJson.features == null) {}
		else {
		actualTime = PropertiesFromJson.features.time1;
		}
		
		DirectionLight.transform.Rotate(0, Time.deltaTime*10, 0, Space.Self);
		tunnel.transform.Rotate(0, Time.deltaTime, 0, Space.Self);
		SolarSystem.transform.Rotate(0,Time.deltaTime*-10 , 0, Space.Self);
	
		
		checkUpdateEQ();
		
		if(Input.GetKeyDown("space")) {
			storeEarthquakes();
		}
		
		if(Input.GetKeyDown("s")) {
			sph = !sph;
				if(sph==true)earthMap.SetActive(true);
				if(sph==false)earthMap.SetActive(false);
		}
		
		if(Input.GetKeyDown("t")) {
			tun = ! tun;
			if(tun==true)tunnel.SetActive(true);
			if(tun==false)tunnel.SetActive(false);
				
		}
		
	
		
	}
	
	void storeEarthquakes () {
		// SolveNullReferenceException error
		if ( PropertiesFromJson.features == null) { Debug.Log("reading...");}
		else{
		actualTime = PropertiesFromJson.features.time1;

		GameObject new3dPoly = Instantiate(selector, transform.localScale, Quaternion.identity) as GameObject;
	    new3dPoly.transform.parent = GameObject.Find("SolarSystem").transform;
		 // instazia dentro solarsystem
		new3dPoly.transform.localScale = new Vector3(1, 1, (float)PropertiesFromJson.features.mag1); 
		SphericalToCartesian( 100.0f, (float)PropertiesFromJson.features.longitude1, (float)PropertiesFromJson.features.latitude1, (float)PropertiesFromJson.features.depth1, out outCart);
		new3dPoly.transform.localRotation = Quaternion.identity;
		new3dPoly.transform.localPosition = outCart;
		ArrayTerremotiGameObject[cnt] = new3dPoly; 	
			
			
//		TextMesh allMesh = Instantiate(TextSelector, transform.localScale, Quaternion.identity ) as TextMesh;
//		allMesh.transform.parent = GameObject.Find("SolarSystem").transform; 
//		GetComponent<TextMesh>().text = PropertiesFromJson.features.place;
//		allMesh.transform.position = outCart;
//		text3dMesh[cnt] = allMesh;
			
			
		audio2.Play();
		trig = true; // manda il trig timer per animazione della durata di duration
		}		


	}
	
	void checkUpdateEQ () {
		
		if(actualTime <= oldTime){
		  	//do nothing	
		} else {
 
			cnt = cnt + 1;
			storeEarthquakes();
  	  		oldTime = actualTime;

			}
		
		if(trig == true){
			
				if(duration > 0) {
					// earthquake's animation just for duration time
   					duration -= Time.deltaTime;
					tunnel.transform.position = tunnel.transform.position + UnityEngine.Random.insideUnitSphere * (float)PropertiesFromJson.features.mag1 *10;
					PointLight2.transform.Translate(-Vector3.forward * Time.deltaTime*10);	
					SPECTATORPOV.transform.Translate(Vector3.forward *Time.deltaTime*20);
					
 				}
			
 				if(duration <= 0){
				
					trig = false;
					duration = 11; // to do:fade to duration 
					tunnel.transform.position = new Vector3(0f, 0f, 0f);
 				}
		}
		// if trig == false
		else {
			
			PointLight2.transform.Translate(Vector3.forward *Time.deltaTime*10);
			float t = Mathf.PingPong(Time.time, duration) / duration;
			PointLight2.light.color = Color.Lerp(color0, color1, t);
			SPECTATORPOV.transform.Translate(-Vector3.forward *Time.deltaTime*20);

		}	
	}
	
public static void SphericalToCartesian(float radius, float lon, float lat, float z1, out Vector3 outCart){
		
		Debug.Log("lat: "+lat +"lon: "+lon);
		float a = radius * Mathf.Cos(Mathf.Deg2Rad*lat);
        outCart.x = a * Mathf.Cos(Mathf.Deg2Rad*(lon));
        outCart.z = a * Mathf.Sin(Mathf.Deg2Rad*(lon));
        outCart.y = radius * Mathf.Sin(Mathf.Deg2Rad*lat);// - (z1/6371* radius);	
	}
		
 void OnGUI () {
		
		// Solve NullReferenceException error
 	   if ( PropertiesFromJson.features == null) {}
			else {
		int cnt2 = cnt + 1;
		//string cnt1 = cnt2.ToString();
    	GUI.Label(new Rect(10,10,500,20), "Earthquakes detected since: "+DateTime.Now +" - num: "+cnt2.ToString());
   		GUI.Label(new Rect(10,25,500,20), "Place: "+ PropertiesFromJson.features.place); 
  	    GUI.Label(new Rect(10,40,500,20), "UTC Time: "+PropertiesFromJson.UTCtime);
 	    GUI.Label(new Rect(10,55,500,20), "Magnitude: "+ PropertiesFromJson.features.mag);
 	    GUI.Label(new Rect(10,70,500,20), "Latitude: "+ PropertiesFromJson.features.latitude +" , Longitude: "+ PropertiesFromJson.features.longitude +" , Depth: "+ PropertiesFromJson.features.depth);
			}
		}
////	

	
}
