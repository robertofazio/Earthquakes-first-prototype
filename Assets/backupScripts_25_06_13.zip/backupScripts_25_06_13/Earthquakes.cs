using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;
using System.IO;
using System.Text;

public class Earthquakes : MonoBehaviour {
	
	private GameObject tunnel;
	public GameObject earthMap;
	private GameObject PointLight2;
	private GameObject DirectionLight;
	private LoadJSON PropertiesFromJson;
	
	private ulong oldTime;
	private ulong actualTime;
	private AudioSource audio2;
	private AudioSource audio3;
	public bool trig = false;
	public float duration = 11.0F; 
    public Color color0 = Color.white;
    public Color color1 = Color.blue;
	private int numMaxTerremoti = 1000; // num.Max di GameObject visualizzati 
    public GameObject[] ArrayTerremotiGameObject; 
	public GameObject selector; // seleziono il poligono
//	public List<string> ArrayPlace;
//	public List<float> ArrayMag;
//	public List<float> ArrayLatitude;
//	public List<float> Arraylongitude;
//	public List<float> ArrayDepth; // array di float dentro il quale immagazino la stringa (float)PropertiesFromJson.features.mag1 proveniente da LoadJson
//	
	private int capacity = 1; // inizializzo la capacità degli array a 1 
	private int cnt = -1;
//	public string path;
//	public string FileName;
//	public string datestring;
	
	void Awake () {
	    
		PropertiesFromJson = GetComponent<LoadJSON>(); // prelevo attraverso GetComponent le variabili che si trovano in LoadJson
		AudioSource[] sources;
		sources = GetComponents<AudioSource>();
		audio2 = sources[2];
		 
	}
	void Start () {
		

		actualTime = 0;
		oldTime = 0;
		DirectionLight = GameObject.Find("Directional light");
		PointLight2 = GameObject.Find("Point light 2");
		tunnel = GameObject.Find("TUNNEL8");
		earthMap = GameObject.Find("earthMap");
		// creo un Array di Gameobject con una capacità fissa numMaxTerremoti 
		ArrayTerremotiGameObject = new GameObject[numMaxTerremoti]; 
	}
	
	void Update () {
		if (PropertiesFromJson.features == null) {}
		else {
		actualTime = PropertiesFromJson.features.time1;
		}
		
		DirectionLight.transform.Rotate(0, Time.deltaTime*10, 0, Space.Self);
		checkUpdateEQ();
		
		if(Input.GetKeyDown("space")) {
			storeEarthquakes();
		}
		
	}
	void storeEarthquakes () {
			
		if ( PropertiesFromJson.features == null) { Debug.Log("reading...");}
		else{
		actualTime = PropertiesFromJson.features.time1;

		// instanzio new3dPoly con il le coordinate del Gameobject 
		GameObject new3dPoly = Instantiate(selector, transform.localScale, Quaternion.identity) as GameObject; 
		new3dPoly.transform.localScale = new Vector3(100, 100, 100*(float)PropertiesFromJson.features.mag1); // scalo new3dPoly nelle Z del valore di Mag*100
		new3dPoly.transform.position = new Vector3((float)PropertiesFromJson.features.latitude1 *10, (float)PropertiesFromJson.features.longitude1 *10, (float)PropertiesFromJson.features.depth1 *10); // la posizione del Gameobj coordinate corrisponde ai valori di latidute1, longitude1, depth convertiti in float
		ArrayTerremotiGameObject[cnt] = new3dPoly; // assegno ad ogni elemento dell'array di tipo GameObject l'oggetto instaziato con i rispettivi valori
			
		audio2.Play();
		trig = true; // manda il trig timer per animazione della durata di duration
		}		


	}
	
	void checkUpdateEQ () {
		
		if(actualTime <= oldTime){
		  	//do nothing	
		} else {
 
			cnt = cnt + 1;
			storeEarthquakes();
  	  		oldTime = actualTime;

			}
		if(trig == true){
			
				if(duration > 0){
					// animation duration
   					duration -= Time.deltaTime;
					tunnel.transform.position = tunnel.transform.position + UnityEngine.Random.insideUnitSphere * (float)PropertiesFromJson.features.mag1 *10;
					PointLight2.transform.Translate(-Vector3.forward * Time.deltaTime*10);	
					
 				}
 				if(duration <= 0){
					trig = false;
					duration = 11; // to do:fade to duration 
					
					tunnel.transform.position = new Vector3(488.169f, -549.9034f, 50.28516f);
 				}
		}
		else {
			PointLight2.transform.Translate(Vector3.forward *Time.deltaTime*10);
			float t = Mathf.PingPong(Time.time, duration) / duration;
			PointLight2.light.color = Color.Lerp(color0, color1, t);
		
		}	
	}
		
 void OnGUI () {
		
 	   if ( PropertiesFromJson.features == null) {}
			else {
			
    	GUI.Label(new Rect(10,10,500,20), "Earthquakes detected since: "+DateTime.Now +" - num: "+cnt);
   		GUI.Label(new Rect(10,25,500,20), "Place: "+ PropertiesFromJson.features.place); 
  	    GUI.Label(new Rect(10,40,500,20), "UTC Time: "+PropertiesFromJson.UTCtime);
 	    GUI.Label(new Rect(10,55,500,20), "Magnitude: "+ PropertiesFromJson.features.mag);
 	    GUI.Label(new Rect(10,70,500,20), "Latitude: "+ PropertiesFromJson.features.latitude +" , Longitude: "+ PropertiesFromJson.features.longitude +" , Depth: "+ PropertiesFromJson.features.depth);
			}
		}
////	

	
}
