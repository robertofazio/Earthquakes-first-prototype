// http://www.paultondeur.com/2010/03/23/tutorial-loading-and-parsing-external-xml-and-json-files-with-unity-part-2-json/
using UnityEngine;
using LitJson;
using System;
using System.IO;
using System.Collections;

public class LoadJSON : MonoBehaviour {   	
     	
	public Features features ;
	public string UTCtime;
	public int flag = 2;
	public int maxnumeq;
	public GameObject[] All_Earthquakes; 
	public GameObject Selector;
	
	 
	void Awake () {
			
	}
	
	void Start () {	
		
		if(flag == 1 ) {
			Debug.Log("reading all_hour json...");
			StartCoroutine("loadJson" , 5.0F);
		}
		
		if(flag == 2 ) {
			Debug.Log("reading all_month json...");
			StartCoroutine("loadJson1" , 5.0F);
		}
	
		
	}
	
	
public IEnumerator loadJson(float waitTime) {
		
		yield return new WaitForSeconds(waitTime);
		Debug.Log("Start call to loadJson all_hour every 5 Sec......");
		Start();
	
		//load the JSON file by using the WWW class. [[ se il Json è fuori servizio?? alternativa?? ]]
        WWW www = new WWW("http://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_hour.geojson");
		//Load the data and yield (wait) till it's ready before we continue executing the rest of this method.
        yield return www;
        if (www.error == null)
        {  //Sucessfully loaded the JSON string
            Debug.Log("Loaded following JSON string" + www.text);
            //Process heartquakes found in JSON file
            ProcessFeatures(www.text);
        }
        else
        {
			Debug.Log("ERROR: " + www.error);
        }
    }

    // Once the data is loaded from the provided URL, we need to convert the loaded string into an object of the JsonData type. We can use a static method of the JsonMapper class to achieve this
public void ProcessFeatures(string jsonString) {	
		
		JsonData jsonFeatures = JsonMapper.ToObject(jsonString); // string converted into an object
	
		features = new Features(); 
		features.Properties = new ArrayList();
	//	Debug.Log(jsonFeatures["features"][0]["properties"]["place"].ToString());
		features.place = jsonFeatures["features"][0]["properties"]["place"].ToString();
		features.mag = jsonFeatures["features"][0]["properties"]["mag"].ToString();
		features.mag1 = Convert.ToDouble(features.mag);
		features.time = jsonFeatures["features"][0]["properties"]["time"].ToString();
		features.time1 = Convert.ToUInt64(features.time);
		features.latitude = jsonFeatures["features"][0]["geometry"]["coordinates"][0].ToString();
		features.latitude1 = Convert.ToDouble(features.latitude);
		features.longitude = jsonFeatures["features"][0]["geometry"]["coordinates"][1].ToString();
		features.longitude1 = Convert.ToDouble(features.longitude);
		features.depth = jsonFeatures["features"][0]["geometry"]["coordinates"][2].ToString();
		features.depth1 = Convert.ToDouble(features.depth);
		//Debug.Log("--Place:"+features.place +"--Mag: " +features.mag1 +"--Time:"+features.time1 + "--Coordinates: "+features.latitude1 +" , " +features.longitude1 + "Depth: "+features.depth1);
		UTCtime = new DateTime(long.Parse(features.time)*10000).AddYears(1969).ToString("yyyy-MM-dd hh:mm:ss");
		

	}

public IEnumerator loadJson1(float waitTime) {
		
		yield return new WaitForSeconds(waitTime);
		Debug.Log("Start call to loadJson all_month only one time......");
        WWW www = new WWW("http://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_month.geojson");
		// Start();
        yield return www;
        if (www.error == null)
        {  
            Debug.Log("Loaded following JSON string" + www.text);
          //  ProcessFeatures(www.text);
        }
        else
        {
			Debug.Log("ERROR: " + www.error);
        }
	
		JsonData jsonFeatures = JsonMapper.ToObject(www.text);
	    features = new Features(); 
		maxnumeq = jsonFeatures["features"].Count;
	    Debug.Log("total string into all_month: "+maxnumeq);
		features.Properties = new ArrayList();
		
		if(maxnumeq != 0){
			All_Earthquakes = new GameObject[maxnumeq]; 
			// quanti cubi metto dentro la matrice 
				//for(int i= 0; i <= maxnumeq; i++) {
			for(int i= 0; i <= 100; i++) {
				features.mag = jsonFeatures["features"][i]["properties"]["mag"].ToString();
				features.mag1 = Convert.ToDouble(features.mag);
				features.latitude = jsonFeatures["features"][i]["geometry"]["coordinates"][0].ToString();
				features.latitude1 = Convert.ToDouble(features.latitude);
				features.longitude = jsonFeatures["features"][i]["geometry"]["coordinates"][1].ToString();
				features.longitude1 = Convert.ToDouble(features.longitude);
				features.depth = jsonFeatures["features"][i]["geometry"]["coordinates"][2].ToString();
				features.depth1 = Convert.ToDouble(features.depth);
				GameObject All_Polygon = Instantiate(Selector, transform.localScale, Quaternion.identity) as GameObject; 
				All_Polygon.transform.localScale = new Vector3(100, 100, 100*(float)features.mag1); 
				All_Polygon.transform.position = new Vector3((float)features.latitude1 *10, (float)features.longitude1 *10, (float)features.depth1 *10);
				All_Earthquakes[i] = All_Polygon;
		
		}

			flag = 1;
			Start();
			
	}	
	}
	

	
}

